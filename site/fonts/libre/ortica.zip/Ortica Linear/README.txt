Ortica Linear by Benedetta Bovani, published by Collletttivo under the SIL Open Font License 1.1 (OFL.txt).
More: https://www.collletttivo.it/typefaces/ortica

Install the font, then paste from dailyposter.design into Figma.
When you share your poster, credit "Ortica Linear by Benedetta Bovani (Collletttivo)".
