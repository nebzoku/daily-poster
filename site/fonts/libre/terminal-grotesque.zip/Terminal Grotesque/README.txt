Terminal Grotesque by Raphaël Bastide, published by Velvetyne under the SIL Open Font License 1.1 (OFL.txt).
More: https://velvetyne.fr/fonts/terminal-grotesque/

Install the font, then paste from dailyposter.design into Figma.
When you share your poster, credit "Terminal Grotesque by Raphaël Bastide (Velvetyne)", and tag @velvetyne or use #velvetyne_type_foundry.
