Ribes by Luigi Gorlero, published by Collletttivo under the SIL Open Font License 1.1 (OFL.txt).
More: https://www.collletttivo.it/typefaces/ribes

Install the font, then paste from dailyposter.design into Figma.
When you share your poster, credit "Ribes by Luigi Gorlero (Collletttivo)".
