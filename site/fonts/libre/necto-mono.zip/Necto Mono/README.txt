Necto Mono by Marco Condello, published by Collletttivo under the SIL Open Font License 1.1 (OFL.txt).
More: https://www.collletttivo.it/typefaces/necto-mono

Install the font, then paste from dailyposter.design into Figma.
When you share your poster, credit "Necto Mono by Marco Condello (Collletttivo)".
